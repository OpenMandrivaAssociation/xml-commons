
package org.w3c.dom.svg;

public interface SVGAnimatedPreserveAspectRatio {
  public SVGPreserveAspectRatio getBaseVal( );
  public SVGPreserveAspectRatio getAnimVal( );
}
