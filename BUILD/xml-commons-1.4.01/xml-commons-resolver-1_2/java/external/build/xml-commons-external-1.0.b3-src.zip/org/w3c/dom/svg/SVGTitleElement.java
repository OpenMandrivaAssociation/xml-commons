
package org.w3c.dom.svg;

public interface SVGTitleElement extends 
               SVGElement,
               SVGLangSpace,
               SVGStylable {
}
