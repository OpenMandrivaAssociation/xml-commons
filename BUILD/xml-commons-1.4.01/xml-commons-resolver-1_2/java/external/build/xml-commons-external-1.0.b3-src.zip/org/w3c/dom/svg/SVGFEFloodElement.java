
package org.w3c.dom.svg;

public interface SVGFEFloodElement extends 
               SVGElement,
               SVGFilterPrimitiveStandardAttributes {
  public SVGAnimatedString      getIn1( );
}
