
package org.w3c.dom.svg;

public interface SVGURIReference {
  public SVGAnimatedString getHref( );
}
