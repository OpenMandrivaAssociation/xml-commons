
package org.w3c.dom.svg;

public interface SVGExternalResourcesRequired {
  public SVGAnimatedBoolean getExternalResourcesRequired( );
}
