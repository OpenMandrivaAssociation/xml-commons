
package org.w3c.dom.svg;

public interface SVGAnimatedNumberList {
  public SVGNumberList getBaseVal( );
  public SVGNumberList getAnimVal( );
}
