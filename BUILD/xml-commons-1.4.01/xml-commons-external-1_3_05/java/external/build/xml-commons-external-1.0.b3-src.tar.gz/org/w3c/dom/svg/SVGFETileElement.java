
package org.w3c.dom.svg;

public interface SVGFETileElement extends 
               SVGElement,
               SVGFilterPrimitiveStandardAttributes {
  public SVGAnimatedString getIn1( );
}
