
package org.w3c.dom.svg;

public interface SVGFEFuncAElement extends 
               SVGComponentTransferFunctionElement {
}
